/**
 * Interface for all help ticket implementations
 */

public interface HelpQueue {
  /**
   * Adds a ticket
   * @param priority of the ticket to be added
   * @return the id of the new ticket
   */
  public int addTicket( int priority );

  /**
   * removes a ticket from the queue
   * @param ticket the id of the ticket to be removed
   */
  public void removeTicket( int id );

  /**
   * @param id the id of a ticket
   * @return the position of the ticket on the queue, that is, the number of
   * tickets with priority greater than or equal to the ticket
   */
  public int getPosition( int id );

  /**
   * removes the ticket with the highest priority
   * @return the ticket with the highest priority
   */
  public Ticket removeMax();

  /**
   * @param id the id of a ticket
   * @return the priority of the ticket
   */
  public int getPriority( int id );
}

//  [Last modified: 2009 10 21 at 20:53:46 GMT]
