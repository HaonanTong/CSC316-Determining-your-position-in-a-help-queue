#! /usr/bin/python
# Creates a large random instance to be used for testing efficiency

import sys
import os
import random

# probability of a * command -- affects the probability of a warning
STAR_PROBABILITY = 0.01
# number of priorities from which to choose randomly = size *
# PRIORITY_MULTIPLIER; affects number of duplicate priorities
PRIORITY_MULTIPLIER = 1000
# the actual number of choices for a priority, set as a function of size
_number_of_choices = 0

# id of most recent element added
_largest_id = 0

# set of id's of tickets that are still in the queue; some of these may have
# been removed by * commands
_active_ids = set([])

def usage():
    print "Usage: generate_large_instance.py SIZE NUMBER_OF_COMMANDS"
    print " where SIZE is the initial number of tickets"

def create_instance(size, number_of_commands):
    insert_tickets(size)
    add_commands(number_of_commands)

# inserts 'size' tickets with random priorities
def insert_tickets(size):
    for i in range(size):
        plus_command()

# generates a list of commands; ones that involve removal update the set of
# id's; since the id's of items removed by * are unknown, we create a *
# command only infrequently
def add_commands(number_of_commands):
    commands = ['+', '-', '?']
    for i in range(number_of_commands):
        command = random.choice(commands)
        if random.random() < STAR_PROBABILITY:
            command = '*'
        if command == '+':
            plus_command()
        elif command == '-':
            minus_command()
        elif command == '?':
            question_command()
        else:
            # * does not require special handling
            print command

# make sure that the set of id's is updated properly; need to know highest id
# so far to do this
def plus_command():
    global _largest_id
    global _active_ids
    priority = random.randrange(_number_of_choices)
    print "+", priority
    _largest_id = _largest_id + 1
    _active_ids.add(_largest_id)
    
# make sure set of id's is updated properly
def minus_command():
    global _active_ids
    id_to_remove = random.choice(list(_active_ids))
    print '-', id_to_remove
    _active_ids.discard(id_to_remove)

def question_command():
    id_to_ask_about = random.choice(list(_active_ids))
    print '?', id_to_ask_about

def main():
    global _number_of_choices
    if len(sys.argv) != 3:
        usage()
        sys.exit()
    size = int(sys.argv[1])
    number_of_commands = int(sys.argv[2])
    _number_of_choices = PRIORITY_MULTIPLIER * size
    create_instance(size, number_of_commands)

main()

#  [Last modified: 2015 11 04 at 14:18:19 GMT]
