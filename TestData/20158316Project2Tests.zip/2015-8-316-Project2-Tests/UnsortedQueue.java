import java.io.*;
import java.util.*;

/**
 * A help queue implemented as an unsorted array list
 * @author Matt Stallman, 2009/10/22
 */

public class UnsortedQueue implements HelpQueue {
  /** allows us to retreive a priority given an id */
  private TreeMap< Integer, Integer > idToPriority;
  /** the array list implementing the queue */
  private ArrayList< Ticket > queue;
  /** the current id number; increases each time a new ticket is added */
  private int currentId = 0;

  /**
   * Constructor. Initializes instance variables.
   */
  public UnsortedQueue()
  {
    idToPriority = new TreeMap< Integer, Integer >();
    queue = new ArrayList< Ticket >();
  }

  /**
   * @return position of the given priority in the array or -1 if it is not
   * found
   */
  int find( int priority )
  {
    for ( int i = 0; i < queue.size(); i++ )
      if ( queue.get(i).getPriority() == priority ) return i;
    return -1;
  }

  /**
   * Adds a ticket
   * @param priority of the ticket to be added
   * @return the id of the new ticket
   * @throws a warning if an item with the given priority is already in the
   * queue
   */
  public int addTicket( int priority ) throws Warning
  {
    int position = find( priority );
    if ( position >= 0 )
      {
        throw new Warning("a ticket with priority " + priority
                          + " is already in the queue");
      }
    ++currentId;
    queue.add( new Ticket( currentId, priority) );
    idToPriority.put( currentId, priority );
    return currentId;
  }

  /**
   * removes a ticket from the queue
   * @param ticket the id of the ticket to be removed
   * @throws a warning if there is no item with that id or with its priority
   */
  public void removeTicket( int id ) throws Warning
  {
    if ( ! idToPriority.containsKey( id ) )
      throw new Warning("there is no ticket with id = " + id + " in the queue");
    int priority = idToPriority.get( id );
    int position = find( priority );
    if ( position < 0 )
      throw new Warning("priority " + priority +
                        " not found (should not happen)");
    queue.remove(position);
    idToPriority.remove(id);
  }

  /**
   * @param id the id of a ticket
   * @return the position of the ticket on the queue, that is, the number of
   * tickets with priority greater than or equal to the ticket
   * @throws a warning if there is no item with that id or its priority
   */
  public int getPosition( int id ) throws Warning
  {
    if ( ! idToPriority.containsKey( id ) )
      throw new Warning("there is no ticket with id = " + id + " in the queue");
    int priority = idToPriority.get( id );
    int numberOfGreaterItems = 0;
    for ( int i = 0; i < queue.size(); i++ )
      {
        if ( queue.get(i).getPriority() > priority )
          numberOfGreaterItems++;
      }
    return numberOfGreaterItems + 1;
  }

  /**
   * removes the ticket with the highest priority
   * @return the ticket with the highest priority
   * @throws a warning if the queue is empty
   */
  public Ticket removeMax() throws Warning
  {
    if ( queue.size() == 0 )
      throw new Warning("removal attempted when queue is empty");
    int best = Integer.MIN_VALUE;
    Ticket bestTicket = null;
    int bestPosition = 0;
    for ( int i = 0; i < queue.size(); i++ )
      {
        Ticket current = queue.get(i);
        if ( current.getPriority() > best )
          {
            best = current.getPriority();
            bestTicket = current;
            bestPosition = i;
          }
      }
    queue.remove( bestPosition );
    idToPriority.remove( bestTicket.getId() );
    return bestTicket;
  }

  /**
   * @param id the id of a ticket
   * @return the priority of the ticket
   */
  public int getPriority( int id ) throws Warning
  {
    if ( ! idToPriority.containsKey( id ) )
      throw new Warning("there is no ticket with id = " + id + " in the queue");
    int priority = idToPriority.get( id );
    return priority;
  }

  public String toString()
  {
    String retval = "[";
    for ( int i = 0; i < queue.size(); i++ )
      {
        retval += " " + queue.get(i);
      }
    retval += " ]";
    return retval;
  }
}

//  [Last modified: 2009 11 03 at 03:46:50 GMT]
