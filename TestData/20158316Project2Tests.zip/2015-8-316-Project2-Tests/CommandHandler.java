import java.io.*;
import java.util.*;

/** Mathods that read and execute queueing commands
 * @author Matt Stallmann, using a draft by Stuart Robinson as starting point.
 */
public class CommandHandler {
  /** Scanner to be used for command input **/
  private Scanner input;
  /** Help queue on which commands are executed **/
  private HelpQueue queue;
  /** Scanner for the current input line */
  private Scanner lineScanner;
	
  /** Constructor: initializes instance variables */
  public CommandHandler( Scanner input, HelpQueue queue )
  {
    this.input = input;
    this.queue = queue;
  }

  /** Reads next command, using helper methods to interpret and execute it;
   * each command is on a separate line
   * @return true if there is another command
   * @throws a warning if anything goes wrong with the command syntax or its
   * execution */
  public boolean nextCommand() throws Warning
  {
    if ( ! input.hasNextLine() ) return false;
    String line = input.nextLine();
    lineScanner = new Scanner( line );
    // check for blank line
    if ( ! lineScanner.hasNext() ) throw new Warning("blank line");

    // echo the whole command line
    System.out.println( line );

    // command is the first token of the line; look at it and decide what to
    // do next
    String command = lineScanner.next();
    if ( command.equals( "+" ) ) handleAdd();
    else if ( command.equals( "-" ) ) handleRemove();
    else if ( command.equals( "?" ) ) handleQuery();
    else if ( command.equals( "*" ) ) handleMax();
    else if ( command.equals( "p" ) )
      System.out.println( "Queue: " + queue );
    else throw new Warning("invalid command " + command);
    if ( lineScanner.hasNext() )
      throw new Warning("Extra stuff on command line, starting with "
                        + lineScanner.next());
    return true;
  }

  private void handleAdd() throws Warning
  {
    if ( ! lineScanner.hasNext() ) throw new Warning( "missing priority for +" );
    int priority;
    String pString = "";
    try {
      pString = lineScanner.next();
      priority = Integer.parseInt( pString );
    }
    catch ( NumberFormatException nfe ) {
      throw new Warning("priority " + pString + " is not an integer");
    }
    int id = queue.addTicket( priority );
    System.out.printf( "id = %d\n", id );
  }

  private void handleRemove() throws Warning
  {
    if ( ! lineScanner.hasNext() ) throw new Warning( "missing id for -" );
    int id;
    String idString = "";
    try {
      idString = lineScanner.next();
      id = Integer.parseInt( idString );
    }
    catch ( NumberFormatException nfe ) {
      throw new Warning("id " + idString + " is not an integer");
    }
    int priority = queue.getPriority( id );
    int position = queue.getPosition( id );
    queue.removeTicket( id );
    System.out.printf( "%d, pos = %d\n", priority, position );
  }

  private void handleQuery() throws Warning
  {
    if ( ! lineScanner.hasNext() ) throw new Warning( "missing id for ?" );
    int id;
    String idString = "";
    try {
      idString = lineScanner.next();
      id = Integer.parseInt( idString );
    }
    catch ( NumberFormatException nfe ) {
      throw new Warning("id " + idString + " is not an integer");
    }
    int position = queue.getPosition( id );
    System.out.printf( "pos = %d\n", position );
  }

  private void handleMax() throws Warning
  {
    Ticket t = queue.removeMax();
    System.out.printf( "id = %d, %d\n", t.getId(), t.getPriority() );
  }

  /**
   * Test program: parses a sequence of commands using the dummy help queue
   */
  public static void main( String [] args )
  {
    DummyQueue d = new DummyQueue();
    Scanner s = new Scanner( System.in );
    CommandHandler ch = new CommandHandler( s, d );
    boolean keepGoing = true;
    while ( keepGoing )
      {
        try {
          keepGoing = ch.nextCommand();
        }
        catch ( Warning w ) {
          System.out.println(w);
        }
      }
  }
}

//  [Last modified: 2009 10 22 at 16:00:46 GMT]
