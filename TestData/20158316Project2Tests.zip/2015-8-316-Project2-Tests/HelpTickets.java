import java.io.*;
import java.util.*;

/**
 * Main program for the help ticket problem (Project 2, CSC 316-001, Fall
 * 2009); this is completely independent of queue implementation except for
 * the line that instantiates the queue. Uses classes<br>
 *  - CommandHandler to read and execute commands<br>
 *  - a class that implements HelpQueue<br>
 *  - Ticket to store information about a help ticket/request<br>
 *  - Warning for exception handling
 * @author Matt Stallmann, 2009/10/22.
 */
public class HelpTickets {

  /**
   * Implementation of the help ticket handling
   */
  public static void main( String [] args )
  {
    // Help queue on which commands are executed (instantiated here)
    UnsortedQueue queue = new UnsortedQueue();
    // Scanner to be used for command input
    Scanner input = new Scanner(System.in);
    // handler: reads and executes commands (also produces output)
    CommandHandler handler = new CommandHandler( input, queue );
    // keep executing commands as long as there are some
    boolean keepGoing = true;
    while ( keepGoing )
      {
        try {
          keepGoing = handler.nextCommand();
        }
        catch ( Warning w ) {
          System.out.println(w);
        }
      }
  }
}

//  [Last modified: 2009 10 22 at 15:19:37 GMT]
