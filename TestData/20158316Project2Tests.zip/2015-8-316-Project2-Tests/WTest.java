public class WTest {
  public boolean doIt( int x ) throws Warning
  {
    if ( x > 5 ) return false;
    throw new Warning("test " + x);
  }
  public static void main( String [] args )
  {
    WTest wt = new WTest();
    boolean c = true;
    int i = 0;
    while ( c )
      {
        try {
          i++;
          System.out.println(i);
          c = wt.doIt(i);
        }
        catch ( Warning w ) {
          System.out.println(w);
        }
      }
  }
}

//  [Last modified: 2009 10 21 at 20:00:48 GMT]
