/**
 * A dummy implementation of a help queue for debugging
 */

public class DummyQueue implements HelpQueue {
  private int currentId = 0;

  public int addTicket( int priority )
  { 
    ++currentId;
    int id = currentId;
    System.out.printf("addTicket: id = %d, priority = %d\n", id, priority);
    return id;
  }

  public void removeTicket( int id )
  {
    System.out.printf("removeTicket: id = %d\n", id);
  }

  public int getPosition( int id )
  {
    System.out.printf("getPosition: id = %d\n", id );
    return 0;
  }

  public Ticket removeMax()
  {
    System.out.printf("removeMax\n");
    return new Ticket( -1, -1 );
  }

  public int getPriority( int id )
  {
    System.out.printf("getPriority: id = %d\n", id );
    return 0;
  }
}

//  [Last modified: 2009 10 21 at 19:32:30 GMT]
