public class Ticket {
  private int id;
  private int priority;
  public Ticket( int id, int priority )
  {
    this.id = id;
    this.priority = priority;
  }
  public int getId() { return id; }
  public int getPriority() { return priority; }
  public String toString() { return "(" + id + "," + priority + ")"; }
}

//  [Last modified: 2009 10 22 at 15:52:04 GMT]
