/**
 * Runtime exception/warning thrown if any problem arises in handling of help
 * ticket commands
 */

public class Warning extends RuntimeException {
  public Warning(String err) {
    super(err);
  }
}

//  [Last modified: 2009 10 21 at 18:44:57 GMT]
